## Artificial_Intelligence_CSCI561
Problem Assignments and Solutions for CSCI 561 Artificial Intelligence

### Homework 1
**Uninformed and Informed Search**: applications of BFS, DFS, UCS and A-Star Algorithms in real-world problem.

### Homework 2 | Google Competiiton
**Gang Wars - Game Playing Intelligent Agent**: state-of-the-art for accessible, deterministic and rational game playing using minimax algorithm and alpha-Beta pruning. The agent competes with all other agents of the 600+ students enrolled in this course.
